# The type af a target analyzer. This matches the Xlang module in
# semgrep-core/osemgrep.
