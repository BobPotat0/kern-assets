class OptionGroup:
    ...


class RequiredAnyOptionGroup(OptionGroup):
    ...


class MutuallyExclusiveOptionGroup(OptionGroup):
    ...


class RequiredMutuallyExclusiveOptionGroup(OptionGroup):
    ...
