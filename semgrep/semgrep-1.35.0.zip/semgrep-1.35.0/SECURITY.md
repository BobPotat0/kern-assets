# Security Policy

## Supported Versions

This project is under active development and we do our best to support the latest versions.

| Version | Supported          |
| ------- | ------------------ |
| latest  | :white_check_mark: |

## Reporting a Vulnerability

Please email security@r2c.dev with any security issues in Semgrep. We take all reports seriously.
